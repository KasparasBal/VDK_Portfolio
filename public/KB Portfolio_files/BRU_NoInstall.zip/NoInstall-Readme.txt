This ZIP file contains all the Bulk Rename Utility files for all the Windows platforms in a compressed file without installer.
Useful to have a fully working program that is portable and can be run from a write-protected disc or on a computer where you have no installation privileges.



For 64-bit versions for Windows
===============================

1) Extract all the files from the 64-bit folder to a folder.
2) Extract all the files from the "All" folder to the SAME folder (optional)



For 32-bit versions for Windows
===============================

1) Extract all the files from the 32-bit folder to a folder
2) Extract all the files from the "All" folder to the SAME folder (optional)



For Windows Vista / XP/ 2003
============================
1) Extract all the files from the Vista-XP-2003 folder to a folder.
2) Extract all the files from the "All" folder to the SAME folder (optional)
* Please note: Bulk Rename Utility for Windows Vista / XP/ 2003 is version 3.2.0.1, which is the last Bulk Rename Utility version that is compatible with Windows Vista / XP/ 2003.


End of file